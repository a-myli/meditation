from datetime import datetime, timezone
import json
from pathlib import Path

import edfio
import mne
import numpy as np
import pandas as pd
import pytest
from scipy.io import savemat

from meditation_eeg.features import extract_features
from meditation_eeg.loading import load_recording
from meditation_eeg.pipeline import read_config, run
from meditation_eeg.preprocessing import clean_raw, resample
from meditation_eeg.segmentation import annotations, create_epochs, find_triggers, resolve_stages


@pytest.fixture
def settings():
    return read_config(Path(__file__).resolve().parents[1] / "config.toml")


@pytest.fixture
def raw():
    rate = 512
    times = np.arange(rate * 20) / rate
    data = np.array([12e-6 * np.sin(2*np.pi*10*times) + 10e-6 * np.sin(2*np.pi*60*times),
                     10e-6 * np.sin(2*np.pi*6*times),
                     np.zeros(len(times)), np.zeros(len(times))])
    data[3, 513] = 1
    data[3, 514] = 2
    data[3, 3328] = 2
    raw = mne.io.RawArray(data, mne.create_info(
        ["F3", "F4", "Cz", "Trigger"], rate, ["eeg", "eeg", "eeg", "stim"],
    ), first_samp=256)
    raw.set_meas_date(datetime(2020, 1, 1, tzinfo=timezone.utc))
    raw.set_annotations(mne.Annotations([7, 11.5], [0.5, 0.25], ["BAD_motion", "original"]))
    return raw


def test_trigger_timing_and_filtering(raw, settings):
    config = settings["processing"]
    events = find_triggers(raw)
    assert events["Trigger"][:, 2].tolist() == [1, 2, 2]
    assert events["Trigger"][0, 0] == 769
    clean, quality, _, _, _ = clean_raw(raw, config)
    assert clean.info["bads"] == ["Cz"]
    assert quality.set_index("channel").loc["Cz", "flat"]
    np.testing.assert_array_equal(clean.get_data(picks=["Trigger"]), raw.get_data(picks=["Trigger"]))
    # Check attenuation in the middle, away from FIR boundaries and the BAD span.
    segment = slice(13 * 512, 18 * 512)
    before, after = [np.abs(np.fft.rfft(item.get_data(picks=["F3"])[0, segment])) for item in (raw, clean)]
    assert after[300] < 0.02 * before[300]
    assert after[50] > 0.95 * before[50]
    mapped, _ = resample(clean, events, 256, 41)
    assert clean.info["sfreq"] == 256
    np.testing.assert_allclose(mapped["Trigger"][:, 0] / 256, events["Trigger"][:, 0] / 512, atol=1/256)
    assert annotations(clean)[0]["onset"] == pytest.approx(7)
    assert clean.info["meas_date"] == raw.info["meas_date"]


def test_verified_stages_allow_absent_event_ids(raw, settings):
    options = settings["stages"]
    options.update(source="triggers", provenance="synthetic test", stim_channel="Trigger",
                   trigger_pairs={"meditation": {"start": 1, "end": 2},
                                  "post_meditation": {"start": 3, "end": 4}})
    raw = raw.copy()
    # Use explicit start/end pulses with a stage long enough for one epoch.
    stim = raw.get_data(picks=["Trigger"])[0]
    stim[514] = stim[3328] = 0
    raw.apply_function(lambda _: stim, picks=["Trigger"])
    with pytest.raises(ValueError, match="Unpaired"):
        resolve_stages(raw, find_triggers(raw), options, {})
    stim[6500] = 2
    raw.apply_function(lambda _: stim, picks=["Trigger"])
    intervals = resolve_stages(raw, find_triggers(raw), options, {})
    assert len(intervals) == 1
    assert intervals[0][0] == "meditation"
    assert intervals[0][1] == 513 / 512


def test_epoch_stage_bounds_bad_intervals_and_features(raw, settings):
    config = settings["processing"]
    clean, _, _, _, _ = clean_raw(raw, config)
    resample(clean, find_triggers(raw), 256, 41)
    stages = [("pre_meditation", 0.001, 5.099), ("meditation", 5.101, 14.899)]
    epochs, candidates = create_epochs(clean, stages, config)
    assert len(candidates) == 3
    assert len(epochs) == 2
    assert candidates[1]["reasons"] == ["BAD_motion"]
    assert epochs.get_data().shape == (2, 2, 1280)
    for row in candidates:
        stage, onset, duration = next(stage for stage in stages if stage[0] == row["stage"])
        assert onset <= row["epoch_start_seconds"] <= onset + duration - 5
    features = extract_features(epochs, {"participant_id": "fixture", "session_id": "test"})
    assert len(features) == 2 * 2 * 3
    assert set(features.stage) == {"pre_meditation", "meditation"}
    assert features.query("channel == 'F3' and band == 'alpha'").relative_power.min() > 0.9
    np.testing.assert_allclose(features.groupby(["epoch_start_seconds", "channel"]).relative_power.sum(), 1)


def test_no_montage_or_eog_and_all_rejected(raw, settings):
    config = settings["processing"]
    config.update(interpolate=True, inspect_ica=True, reject_peak_uv=0.1)
    with pytest.warns(UserWarning) as warnings:
        clean, _, model, _, report = clean_raw(raw, config)
    assert any("No usable EOG" in str(w.message) for w in warnings)
    assert any("Interpolation skipped" in str(w.message) for w in warnings)
    assert model is None
    assert report["removed"] == []
    epochs, candidates = create_epochs(clean, None, config)
    assert len(epochs) == 0
    assert len(candidates) == 4
    assert all(row["reasons"] for row in candidates)
    assert extract_features(epochs, {}).empty


def test_csv_validation_and_original_annotation_clock(raw, settings, tmp_path):
    who = {"participant_id": "test", "session_id": "1", "file": "record.edf"}
    stages = settings["stages"]
    stages.update(provenance="test fixture", source="annotations",
                  annotation_map={"original": "meditation"})
    assert resolve_stages(raw, {}, stages, who) == [("meditation", 11.5, 0.25)]
    csv = tmp_path / "stages.csv"
    rows = pd.DataFrame([{**who, "stage": "meditation", "onset_seconds": 2, "duration_seconds": 7},
                         {**who, "stage": "post_meditation", "onset_seconds": 7, "duration_seconds": 6}])
    rows.to_csv(csv, index=False)
    stages.update(source="csv", csv=csv)
    with pytest.raises(ValueError, match="overlapping"):
        resolve_stages(raw, {}, stages, who)
    rows.iloc[[0]].to_csv(csv, index=False)
    assert resolve_stages(raw, {}, stages, who) == [("meditation", 2, 7)]


def test_legacy_mat_uses_verified_units_and_timestamps(settings, tmp_path):
    config = settings["channels"]
    config["legacy_mat_enabled"] = True
    config["legacy_mat"].update(eeg_unit="uV", timestamp_to_seconds=1)
    path = tmp_path / "fixture.mat"
    matrix = np.zeros((512, 19))
    matrix[:, 0] = 42 + np.arange(512) / 512
    matrix[:, 1] = 10
    savemat(path, {"SIGNAL": matrix.T})
    raw, info = load_recording(path, config)
    assert raw.get_data()[0, 0] == pytest.approx(1e-5)
    assert "42" in info["description"]


def test_synthetic_edf_end_to_end(tmp_path, settings):
    rate = 512
    times = np.arange(rate * 20) / rate
    trigger = np.zeros(len(times))
    trigger[rate:rate + 2] = 1
    trigger[rate * 2:rate * 2 + 2] = 2
    eeg = edfio.EdfSignal(12 * np.sin(2*np.pi*10*times), rate, label="F3", physical_dimension="uV")
    stim = edfio.EdfSignal(trigger, rate, label="Trigger", physical_range=(-32768, 32767))
    name = "record.edf"
    edfio.Edf([eeg, stim], annotations=[edfio.EdfAnnotation(10.2, 0.1, "BAD_move"),
                                      edfio.EdfAnnotation(0.2, 9.9, "protocol_stage")]).write(tmp_path / name)
    manifest = tmp_path / "participants.csv"
    manifest.write_text("file,participant_id,session_id\nrecord.edf,test,one\n")
    settings["paths"] = {"data_dir": tmp_path, "output_dir": tmp_path / "signal", "participants_csv": manifest}
    settings["channels"]["channel_types"] = {"Trigger": "stim"}
    report, = run(settings, name)
    result = tmp_path / "signal" / "test" / "one"
    assert report["candidate_epochs"] == 4
    assert report["rejected_epochs"] == 1
    assert report["trigger_codes"] == {"Trigger": [1, 2]}
    assert pd.read_csv(result / "features.csv").stage.isna().all()
    assert not (result / "stage_power.png").exists()
    assert json.loads((result / "qc.json").read_text())["source"]["edf_signal_headers"][0]["physical_unit"] == "uV"
    assert len(mne.read_epochs(result / "cleaned-epo.fif")) == 3
    reread = mne.io.read_raw_fif(result / "cleaned_raw.fif")
    assert "Trigger" in reread.ch_names
    assert "protocol_stage" in reread.annotations.description

    settings["paths"]["output_dir"] = tmp_path / "labeled"
    settings["mode"] = "meditation"
    settings["stages"].update(source="annotations", provenance="synthetic fixture",
                              annotation_map={"protocol_stage": "meditation"})
    report, = run(settings)
    result = tmp_path / "labeled" / "test" / "one"
    assert report["candidate_epochs"] == 1
    assert (result / "stage_power.png").exists()
    assert set(pd.read_csv(result / "features.csv").stage) == {"meditation"}

    settings["paths"]["output_dir"] = tmp_path / "all_rejected"
    settings["processing"]["detect_flat_uv"] = 100
    report, = run(settings)
    result = tmp_path / "all_rejected" / "test" / "one"
    assert report["retained_epochs"] == 0
    assert report["rejection_reasons"] == {"NO_GOOD_EEG": 1}
    assert pd.read_csv(result / "features.csv").empty
    assert (result / "cleaned_raw.fif").is_file()
    assert not (result / "cleaned-epo.fif").exists()


def test_valid_montage_interpolates_flat_channel(settings):
    rate = 256
    time = np.arange(20 * rate) / rate
    names = ["F3", "F4", "Cz", "P3", "P4"]
    data = np.array([np.sin(2 * np.pi * hz * time) * 10e-6 for hz in (7, 8, 9, 10, 11)])
    data[-1] = 0
    raw = mne.io.RawArray(data, mne.create_info(names, rate, "eeg"))
    config = settings["processing"]
    config.update(montage="standard_1020", interpolate=True, reference="average")
    clean, quality, _, _, _ = clean_raw(raw, config)
    assert quality.set_index("channel").loc["P4", "interpolated"]
    assert "P4" not in clean.info["bads"]
    np.testing.assert_allclose(clean.get_data().mean(axis=0), 0, atol=1e-12)


def test_model_skips_when_labels_or_independent_participants_missing():
    from meditation_eeg.modeling import baseline

    assert baseline(pd.DataFrame(), ["F3"])["status"] == "skipped"
    rows = pd.DataFrame([
        {"participant_id": "fixture", "experience_level": "novice", "stage": stage,
         "session_id": "test", "channel": "F3", "band": band, "relative_power": 1 / 3,
         "power_v2": 1e-12}
        for band in ("theta", "alpha", "beta") for stage in ("pre_meditation", "meditation")
    ])
    result = baseline(rows, ["F3"])
    assert result["status"] == "skipped"
    assert result["participants_per_stage"] == {"meditation": 1, "pre_meditation": 1}


def test_ica_reports_candidates_without_changing_cleaned_eeg(settings, tmp_path):
    from meditation_eeg.qc import plot_ica

    rate = 256
    time = np.arange(70 * rate) / rate
    eog = np.zeros_like(time)
    alpha = np.zeros_like(time)
    beta = np.zeros_like(time)
    for onset in np.arange(2, 68, 2.1):
        eog += 90e-6 * np.exp(-((time - onset) / 0.11)**2)
        tau = time - onset - 0.55
        alpha += 30e-6 * np.sin(2 * np.pi * 9 * tau) * np.exp(-(tau / 0.13)**2)
        tau = time - onset - 1.1
        beta += 20e-6 * np.sin(2 * np.pi * 17 * tau) * np.exp(-(tau / 0.18)**2)
    data = np.vstack([0.6 * eog + alpha, 0.3 * eog + beta, 0.2 * eog + alpha + 0.7 * beta, eog])
    raw = mne.io.RawArray(data, mne.create_info(["F3", "F4", "Cz", "EOG"], rate, ["eeg"] * 3 + ["eog"]))
    config = settings["processing"]
    baseline, *_ = clean_raw(raw, config)
    config["inspect_ica"] = True
    clean, _, model, sources, report = clean_raw(raw, config)
    assert report["status"] == "inspection_only"
    assert report["eog_scores"][0]["candidate_components"]
    assert not report["removed"] and not model.exclude
    np.testing.assert_array_equal(baseline.get_data(), clean.get_data())
    plot_ica(sources, tmp_path)
    assert (tmp_path / "ica_sources.png").stat().st_size > 0
