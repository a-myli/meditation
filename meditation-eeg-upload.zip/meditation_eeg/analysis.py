"""Participant-level exploratory summaries for verified meditation recordings."""
import argparse
from pathlib import Path

from matplotlib.figure import Figure
import pandas as pd

from .qc import save_figure
from .segmentation import STAGES

EXPERIENCE = {"novice", "experienced", "expert"}


def load_labeled(root, manifest):
    frames = [pd.read_csv(path, dtype={"participant_id": str, "session_id": str})
              for path in sorted(Path(root).glob("*/*/features.csv"))]
    if not frames:
        return pd.DataFrame()
    rows = pd.concat(frames, ignore_index=True)
    rows = rows.loc[rows.stage.isin(STAGES) & rows.stage_provenance.fillna("").str.strip().ne("")
                    & rows.qc_status.eq("retained")]
    if rows.empty:
        return rows
    fields = ["participant_id", "session_id", "file"]
    metadata = pd.read_csv(manifest, dtype=str)[fields + ["experience_level"]]
    data = rows.merge(metadata, on=fields, how="left", validate="many_to_one", indicator=True)
    if not data["_merge"].eq("both").all():
        raise ValueError("Verified features must match the participant metadata.")
    if data.experience_level.dropna().map(lambda value: value not in EXPERIENCE).any():
        raise ValueError("Experience must be novice, experienced, expert, or blank.")
    if (data.groupby("participant_id").experience_level.nunique() > 1).any():
        raise ValueError("Experience labels conflict within participants.")
    return data.drop(columns="_merge")


def participant_stage_power(rows):
    values = ["power_v2", "relative_power"]
    keys = ["participant_id", "experience_level", "stage", "channel", "band"]
    sessions = rows.groupby(keys + ["session_id"], dropna=False)[values].mean()
    return sessions.groupby(level=keys, dropna=False).mean().reset_index()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--processed", required=True)
    parser.add_argument("--participants", required=True)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--channel", required=True, help="Preselect one channel for the exploratory plot.")
    args = parser.parse_args()
    rows = load_labeled(args.processed, args.participants)
    if rows.empty:
        print("Skipped analysis: no verified stage features are available.")
        return
    participants = participant_stage_power(rows)
    group_keys = ["experience_level", "stage", "channel", "band"]
    groups = participants.groupby(group_keys, dropna=False).agg(
        participants=("participant_id", "nunique"), mean_power_v2=("power_v2", "mean"),
        mean_relative_power=("relative_power", "mean"),
    )
    args.output.mkdir(parents=True, exist_ok=False)
    participants.to_csv(args.output / "participant_stage_power.csv", index=False)
    groups.to_csv(args.output / "experience_stage_power.csv")
    channel = participants.loc[participants.channel.eq(args.channel)]
    if channel.empty:
        print(f"No retained features for {args.channel}. Saved tables.")
        return
    fig = Figure(figsize=(11, 4), layout="constrained")
    for (band, ax) in zip(("theta", "alpha", "beta"), fig.subplots(1, 3, sharey=True), strict=True):
        selected = channel.loc[channel.band.eq(band)]
        for i, (level, group) in enumerate(selected.groupby("experience_level", dropna=False)):
            offsets = group.stage.map({name: j for j, name in enumerate(STAGES)}) + 0.08 * i
            ax.scatter(offsets, group.relative_power, label=str(level) if pd.notna(level) else "Unknown", alpha=0.6)
        ax.set(title=f"{args.channel} {band}", xticks=range(len(STAGES)),
               xticklabels=["Pre", "During", "Post"], ylim=(0, 1.02))
    fig.axes[0].set_ylabel("Participant mean relative power")
    if fig.axes[-1].collections:
        fig.axes[-1].legend()
    save_figure(fig, args.output / "participant_power.png")


if __name__ == "__main__":
    main()
