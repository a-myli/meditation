"""Save static QC plots without opening a GUI."""
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
import numpy as np
from scipy.signal import welch


def save_figure(figure, path):
    FigureCanvasAgg(figure)
    figure.savefig(path, dpi=140, bbox_inches="tight")


def plot_signals(original, cleaned, channels, output):
    trace = Figure(figsize=(10, 6), layout="constrained")
    spectrum = Figure(figsize=(10, 4), layout="constrained")
    traces = trace.subplots(2, 1, sharex=True)
    spectra = spectrum.subplots(1, 2, sharex=True, sharey=True)
    for raw, title, ax, psd_ax in zip(
        (original, cleaned), ("Original", "Cleaned"), traces, spectra, strict=True,
    ):
        rate = raw.info["sfreq"]
        data = raw.get_data(picks=channels) * 1e6
        stop = min(data.shape[1], round(10 * rate))
        show = data[:8, :stop]
        scale = max(1, np.percentile(np.abs(show), 95) * 3)
        offsets = np.arange(len(show)) * scale
        ax.plot(np.arange(stop) / rate, (show + offsets[:, None]).T, linewidth=0.6)
        ax.set(yticks=offsets, yticklabels=channels[:8], title=f"{title} EEG (traces offset, µV)")
        hz, density = welch(data, fs=rate, nperseg=min(round(4 * rate), data.shape[-1]), axis=-1)
        psd_ax.semilogy(hz, np.maximum(density.T, np.finfo(float).tiny), linewidth=0.75)
        psd_ax.set(title=title, xlabel="Hz", xlim=(0, min(80, cleaned.info["sfreq"] / 2)))
    traces[-1].set_xlabel("Seconds from recording start")
    spectra[0].set_ylabel("Welch PSD (µV²/Hz)")
    save_figure(trace, output / "eeg_samples.png")
    save_figure(spectrum, output / "psd_comparison.png")


def plot_features(features, output):
    if features.empty:
        return
    figure = Figure(figsize=(9, 4), layout="constrained")
    ax = figure.subplots()
    for band, rows in features.groupby("band"):
        points = rows.groupby("epoch_start_seconds").relative_power.median()
        ax.plot(points.index, points.values, "o-", label=band, markersize=3)
    ax.set(xlabel="Epoch start (s)", ylabel="Median relative power across included channels")
    ax.legend()
    save_figure(figure, output / "power_over_time.png")
    labeled = features.loc[features.stage.ne("")]
    if not labeled.empty:
        figure = Figure(figsize=(8, 4), layout="constrained")
        ax = figure.subplots()
        table = labeled.groupby(["stage", "band"]).relative_power.mean().unstack()
        table.plot.bar(ax=ax, rot=0)
        ax.set(ylabel="Mean relative power across retained epochs and channels")
        save_figure(figure, output / "stage_power.png")


def plot_ica(sources, output):
    rate = sources.info["sfreq"]
    data = sources.get_data(stop=min(sources.n_times, round(15 * rate)))
    figure = Figure(figsize=(10, max(3, 0.65 * len(data))), layout="constrained")
    axes = figure.subplots(len(data), 1, sharex=True, squeeze=False).ravel()
    for index, (ax, signal) in enumerate(zip(axes, data, strict=True)):
        ax.plot(np.arange(len(signal)) / rate, signal, linewidth=0.6)
        ax.set_ylabel(str(index), rotation=0, labelpad=12)
    axes[0].set_title("ICA source time courses (arbitrary units)")
    axes[-1].set_xlabel("Seconds from recording start")
    save_figure(figure, output / "ica_sources.png")
