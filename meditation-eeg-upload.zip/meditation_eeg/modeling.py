"""Optional participant-grouped stage classification on verified features."""
import argparse
import json

import numpy as np
from sklearn.base import clone
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score, confusion_matrix
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from .analysis import load_labeled, participant_stage_power
from .features import BANDS


def baseline(rows, channels, folds=3):
    if rows.empty:
        return {"status": "skipped", "reason": "No verified stage features"}
    if not channels or len(set(channels)) != len(channels) or folds < 2:
        raise ValueError("Specify unique preselected channels and at least two folds.")
    participant_power = participant_stage_power(rows)
    matrix = participant_power.pivot(index=["participant_id", "stage"],
                                     columns=["channel", "band"], values="relative_power")
    columns = [(channel, band) for channel in channels for band in BANDS]
    matrix = matrix.reindex(columns=columns).dropna()
    groups = matrix.index.get_level_values("participant_id").to_numpy()
    labels = matrix.index.get_level_values("stage").to_numpy()
    classes, counts = np.unique(labels, return_counts=True)
    balance = dict(zip(classes.tolist(), counts.tolist(), strict=True))
    excluded = participant_power[["participant_id", "stage"]].drop_duplicates().shape[0] - len(matrix)
    if len(classes) < 2 or min(counts) < folds:
        return {"status": "skipped", "reason": "Too few complete independent participants per stage",
                "participants_per_stage": balance, "excluded_participant_stages": excluded}
    splitter = StratifiedGroupKFold(n_splits=folds, shuffle=True, random_state=42)
    splits = list(splitter.split(matrix, labels, groups))
    if any(set(labels[train]) != set(classes) or set(labels[test]) != set(classes) for train, test in splits):
        return {"status": "skipped", "reason": "A participant-grouped fold lacks a stage",
                "participants_per_stage": balance}
    model = make_pipeline(StandardScaler(), LogisticRegression(class_weight="balanced", max_iter=1000))
    predictions = labels.copy()
    for train, test in splits:
        estimator = clone(model).fit(matrix.iloc[train], labels[train])
        predictions[test] = estimator.predict(matrix.iloc[test])
    return {
        "status": "evaluated", "participants_per_stage": balance, "folds": folds,
        "excluded_participant_stages": excluded, "classes": classes.tolist(),
        "balanced_accuracy": balanced_accuracy_score(labels, predictions),
        "confusion_matrix": confusion_matrix(labels, predictions, labels=classes).tolist(),
        "limitations": ("Exploratory grouped CV on participant-stage averages. Performance depends on "
                        "the acquisition protocol and is not an estimate of online epoch classification."),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--processed", required=True)
    parser.add_argument("--participants", required=True)
    parser.add_argument("--channels", nargs="+", required=True)
    parser.add_argument("--folds", type=int, default=3)
    args = parser.parse_args()
    print(json.dumps(baseline(load_labeled(args.processed, args.participants), args.channels, args.folds), indent=2))


if __name__ == "__main__":
    main()
