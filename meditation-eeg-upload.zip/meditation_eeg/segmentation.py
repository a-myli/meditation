"""Resolve verified intervals on the acquisition clock, then build complete epochs."""
import math

import mne
import numpy as np
import pandas as pd

STAGES = ("pre_meditation", "meditation", "post_meditation")


def annotations(raw):
    # Stored annotation onsets include the Raw first-sample offset.
    return [{**item, "onset": float(item["onset"] - raw.first_time)}
            for item in raw.annotations]


def find_triggers(raw):
    events = {}
    for channel, kind in zip(raw.ch_names, raw.get_channel_types()):
        if kind != "stim":
            continue
        values = raw.get_data(picks=[channel])[0]
        if (not np.isfinite(values).all() or np.any(values < 0)
                or np.any(np.abs(values - np.rint(values)) > 1e-6)):
            raise ValueError(f"{channel} is not a nonnegative integer stimulus stream. Verify its encoding.")
        if np.any(values >= 2**53):
            raise ValueError(f"{channel} contains codes outside the exact floating-point integer range.")
        codes = np.rint(values).astype(np.int64)
        previous = np.r_[0, codes[:-1]]
        onsets = np.flatnonzero((codes != previous) & (codes != 0))
        events[channel] = np.column_stack((onsets + raw.first_samp, previous[onsets], codes[onsets]))
    return events


def resolve_stages(raw, events, settings, recording):
    source = settings["source"]
    if not settings.get("provenance", "").strip():
        raise ValueError("Specify the verified protocol or timing-log provenance.")
    intervals = []
    if source == "csv":
        rows = pd.read_csv(settings["csv"], dtype=str, keep_default_na=False)
        for key in ("file", "participant_id", "session_id"):
            rows = rows.loc[rows[key] == recording[key]]
        intervals = [(r.stage, float(r.onset_seconds), float(r.duration_seconds))
                     for r in rows.itertuples()]
    elif source == "annotations":
        mapping = settings["annotation_map"]
        intervals = [(mapping[a["description"]], a["onset"], a["duration"])
                     for a in annotations(raw) if a["description"] in mapping]
    elif source == "triggers":
        channel = settings["stim_channel"]
        if channel not in events:
            raise ValueError(f"Configured stage trigger channel {channel!r} is absent.")
        # Use explicit start/end pairs. Unobserved pairs are allowed.
        values = events[channel]
        pairs = settings["trigger_pairs"]
        if set(pairs) - set(STAGES):
            raise ValueError("Unknown stage in trigger mapping.")
        codes = [pair[key] for pair in pairs.values() for key in ("start", "end")]
        if any(type(code) is not int or code <= 0 for code in codes) or len(set(codes)) != len(codes):
            raise ValueError("Stage trigger codes must be unique positive integers.")
        for stage, pair in settings["trigger_pairs"].items():
            starts = values[values[:, 2] == int(pair["start"]), 0]
            ends = values[values[:, 2] == int(pair["end"]), 0]
            if len(starts) != len(ends):
                raise ValueError(f"Unpaired start/end markers for {stage}.")
            for start, end in zip(starts, ends):
                rate = raw.info["sfreq"]
                intervals.append((stage, (start - raw.first_samp) / rate, (end - start) / rate))
    else:
        raise ValueError("Meditation mode requires a validated stage source.")
    if not intervals:
        raise ValueError("No verified stage intervals matched the recording.")
    limit = raw.n_times / raw.info["sfreq"]
    previous_end = 0
    for stage, start, length in sorted(intervals, key=lambda row: row[1]):
        if stage not in STAGES or not math.isfinite(start) or not math.isfinite(length):
            raise ValueError(f"Invalid stage interval: {(stage, start, length)}")
        if start < 0 or length <= 0 or start + length > limit + 1e-9 or start < previous_end - 1e-9:
            raise ValueError(f"Out-of-bounds or overlapping stage interval: {(stage, start, length)}")
        previous_end = start + length
    return sorted(intervals, key=lambda row: row[1])


def create_epochs(raw, intervals, config, acquisition_duration=None):
    sfreq = raw.info["sfreq"]
    size = round(5 * sfreq)
    if not math.isclose(size, 5 * sfreq, abs_tol=1e-7):
        raise ValueError("Five seconds must be representable as a whole number of samples.")
    if intervals is None:
        duration = raw.n_times / sfreq if acquisition_duration is None else acquisition_duration
        intervals = [(None, 0, duration)]
    bad_intervals = [a for a in annotations(raw) if a["description"].lower().startswith("bad")]
    candidates, events, indices = [], [], []
    eeg = mne.pick_types(raw.info, eeg=True, exclude="bads")
    codes = {stage: i for i, stage in enumerate((None, *STAGES), 1)}
    for stage, onset, duration in intervals:
        # Round inward so a candidate never crosses a stage edge.
        start = math.ceil(onset * sfreq - 1e-8)
        stop = min(raw.n_times, math.floor((onset + duration) * sfreq + 1e-8))
        for sample in range(start, stop - size + 1, size):
            begin, end = sample / sfreq, (sample + size) / sfreq
            reasons = [a["description"] for a in bad_intervals if
                       (a["onset"] < end and a["onset"] + a["duration"] > begin)
                       or (a["duration"] == 0 and begin <= a["onset"] < end)]
            if not eeg.size:
                reasons.append("NO_GOOD_EEG")
            candidates.append({"stage": stage, "epoch_start_seconds": begin,
                               "sample": sample + raw.first_samp, "reasons": reasons})
            if not reasons:
                events.append([sample + raw.first_samp, 0, codes[stage]])
                indices.append(len(candidates) - 1)
    epochs = None
    if events:
        present = {str(stage or "fixed_length"): codes[stage]
                   for stage in {candidates[i]["stage"] for i in indices}}
        metadata = pd.DataFrame([{
            "stage": candidates[i]["stage"] or "",
            "epoch_start_seconds": candidates[i]["epoch_start_seconds"],
        } for i in indices])
        epochs = mne.Epochs(
            raw, np.array(events), event_id=present, tmin=0, tmax=(size - 1) / sfreq,
            picks=eeg, preload=True, baseline=None, detrend=0, proj=False,
            reject={"eeg": config["reject_peak_uv"] * 1e-6},
            flat={"eeg": config["reject_flat_uv"] * 1e-6},
            reject_by_annotation=True, metadata=metadata,
        )
        for index, reasons in zip(indices, epochs.drop_log, strict=True):
            if not reasons:
                continue
            row = candidates[index]
            start = row["sample"] - raw.first_samp
            for reason in reasons:
                if reason in epochs.ch_names:
                    samples = raw.get_data(picks=[reason], start=start, stop=start + size)
                    peak_uv = np.ptp(samples) * 1e6
                    criterion = "peak_to_peak" if peak_uv > config["reject_peak_uv"] else "flat"
                    row["reasons"].append(f"{criterion}:{reason}")
                else:
                    row["reasons"].append(reason)
    return epochs, candidates
