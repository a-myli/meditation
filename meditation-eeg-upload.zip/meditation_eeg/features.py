"""Welch feature extraction and session summaries."""
import numpy as np
import pandas as pd

BANDS = {"theta": (4, 8), "alpha": (8, 13), "beta": (13, 30)}
POWERS = ["power_v2", "relative_power", "theta_beta", "alpha_beta"]


def extract_features(epochs, recording, interpolated=()):
    columns = ["participant_id", "session_id", "file", "stage", "epoch_start_seconds",
               "channel", "band", *POWERS, "qc_status", "stage_provenance"]
    if epochs is None or not len(epochs):
        return pd.DataFrame(columns=columns)
    n_fft = round(2 * epochs.info["sfreq"])
    spectrum = epochs.compute_psd(
        method="welch", n_fft=n_fft, n_per_seg=n_fft, n_overlap=n_fft // 2,
        window="hann", fmin=4, fmax=30, remove_dc=True,
    )
    density, hz = spectrum.get_data(return_freqs=True)
    df = hz[1] - hz[0]
    power = {band: density[..., (hz >= lower) & (hz < upper)].sum(axis=-1) * df
             for band, (lower, upper) in BANDS.items()}
    total = sum(power.values())
    beta = power["beta"]

    def divide(numerator, denominator):
        return np.divide(numerator, denominator, out=np.full_like(numerator, np.nan), where=denominator > 0)

    theta_beta = divide(power["theta"], beta)
    alpha_beta = divide(power["alpha"], beta)
    rows = []
    for band, values in power.items():
        relative = divide(values, total)
        for i, meta in enumerate(epochs.metadata.itertuples(index=False)):
            for j, channel in enumerate(spectrum.ch_names):
                rows.append({
                    **recording, "stage": meta.stage, "epoch_start_seconds": meta.epoch_start_seconds,
                    "channel": channel, "band": band, "power_v2": values[i, j],
                    "relative_power": relative[i, j], "theta_beta": theta_beta[i, j],
                    "alpha_beta": alpha_beta[i, j],
                    "qc_status": "interpolated" if channel in interpolated else "retained",
                })
    return pd.DataFrame(rows, columns=columns)


def summarize(features):
    keys = ["participant_id", "session_id", "stage", "channel", "band", "qc_status"]
    return features.groupby(keys, dropna=False)[POWERS].mean().join(
        features.groupby(keys, dropna=False).size().rename("epoch_count"),
    ).reset_index()
