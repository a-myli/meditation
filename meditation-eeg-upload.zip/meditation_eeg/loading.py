"""Load recordings and report acquisition metadata."""
from pathlib import Path

import mne
import numpy as np
from scipy.io import loadmat


def discover(directory, include_mat=False):
    suffixes = {".edf", ".mat"} if include_mat else {".edf"}
    return sorted(p for p in Path(directory).iterdir() if p.is_file() and p.suffix.lower() in suffixes)


def edf_signal_headers(path):
    """Read EDF signal labels, calibration units and per-channel rates."""
    with path.open("rb") as handle:
        header = handle.read(256)
        count = int(header[252:256])
        record_seconds = float(header[244:252])
        fields = []
        for width in (16, 80, 8, 8, 8, 8, 8, 80, 8, 32):
            field = handle.read(width * count)
            fields.append([field[i:i + width].decode("latin-1").strip()
                           for i in range(0, len(field), width)])
    return [{"label": label, "physical_unit": unit, "native_rate_hz": int(samples) / record_seconds}
            for label, unit, samples in zip(fields[0], fields[2], fields[8], strict=True)]


def load_recording(path, config):
    path = Path(path)
    if path.suffix.lower() == ".edf":
        # Preserve EDF calibration, measurement date and TAL annotations.
        stim = [name for name, kind in config["channel_types"].items() if kind == "stim"]
        reverse = {new: old for old, new in config["rename"].items()}
        raw = mne.io.read_raw_edf(
            path, preload=True, infer_types=config["infer_edf_types"],
            stim_channel=[reverse.get(name, name) for name in stim] or None,
        )
    elif path.suffix.lower() == ".mat" and config["legacy_mat_enabled"]:
        raw = load_legacy_mat(path, config["legacy_mat"])
    else:
        raise ValueError("Select an EDF or explicitly enable the legacy MATLAB importer.")

    original = inventory(raw)
    if path.suffix.lower() == ".edf":
        original["edf_signal_headers"] = edf_signal_headers(path)
    rename = config["rename"]
    missing = set(rename) - set(raw.ch_names)
    if missing:
        raise ValueError(f"Rename sources absent: {sorted(missing)}")
    names = [rename.get(name, name) for name in raw.ch_names]
    if len(set(names)) != len(names):
        raise ValueError("Rename would create duplicate channels.")
    raw.rename_channels(rename)
    types = config["channel_types"]
    if set(types) - set(raw.ch_names):
        raise ValueError(f"Configured channel types refer to absent channels: {sorted(set(types) - set(raw.ch_names))}")
    changes = {name: kind for name, kind in types.items()
               if raw.get_channel_types(picks=[name])[0] != kind}
    raw.set_channel_types(changes)
    # Ambiguous vendor labels require a deliberate type assignment.
    ambiguous = [name for name, kind in zip(raw.ch_names, raw.get_channel_types())
                 if name.strip().casefold() in {"trigger", "event", "status"} and kind == "eeg"]
    if ambiguous:
        raise ValueError(f"Verify and configure channel types for {ambiguous} before filtering.")
    if not np.isfinite(raw.info["sfreq"]) or raw.info["sfreq"] <= 0:
        raise ValueError("Invalid sample rate.")
    eeg = mne.pick_types(raw.info, eeg=True, exclude=[])
    if not eeg.size:
        raise ValueError("Recording has no EEG channels.")
    expected = config.get("expected_eeg", [])
    eeg_names = {raw.ch_names[index] for index in eeg}
    if expected and set(expected) != eeg_names:
        raise ValueError(f"EEG layout differs from expected. Missing: {sorted(set(expected) - eeg_names)}. "
                         f"Unexpected: {sorted(eeg_names - set(expected))}.")
    if path.suffix.lower() == ".edf":
        headers = [row for row in original["edf_signal_headers"]
                   if row["label"] not in {"EDF Annotations", "BDF Annotations"}]
        if len(headers) != len(raw.ch_names):
            raise ValueError("EDF header signal count differs from loaded channel count.")
        for index in eeg:
            unit = headers[index]["physical_unit"]
            if unit not in {"V", "mV", "uV", "µV", "\x83\xcaV"}:
                raise ValueError(f"Invalid or unsupported EDF EEG unit {unit!r} for {raw.ch_names[index]}. "
                                 "Verify the calibration and correct the export.")
    return raw, original


def load_legacy_mat(path, config):
    names = config["eeg_names"]
    width = len(names) + 3
    matrix = np.asarray(loadmat(path)[config["variable"]], dtype=float)
    if matrix.ndim != 2 or matrix.shape.count(width) != 1:
        raise ValueError(f"Expected an unambiguous matrix with {width} columns after orientation.")
    if matrix.shape[1] != width:
        matrix = matrix.T
    sfreq = float(config["sfreq"])
    scale = {"V": 1, "uV": 1e-6}[config["eeg_unit"]]
    timestamps_s = matrix[:, 0] * config["timestamp_to_seconds"]
    if len(matrix) < 2 or not np.allclose(np.diff(timestamps_s), 1 / sfreq, rtol=0.01, atol=1e-7):
        raise ValueError("MATLAB timestamps are incompatible with the configured rate or have gaps.")
    stim = matrix[:, -2:]
    if not np.isfinite(stim).all() or np.any(stim != np.rint(stim)) or np.any(stim < 0):
        raise ValueError("Expected nonnegative integer MATLAB triggers.")
    data = np.column_stack((matrix[:, 1:-2] * scale, stim)).T
    info = mne.create_info(names + ["COND_1", "COND_2"], sfreq, ["eeg"] * len(names) + ["stim"] * 2)
    info["description"] = f"Source MATLAB first timestamp in seconds: {timestamps_s[0]:.12g}"
    return mne.io.RawArray(data, info)


def inventory(raw):
    return {
        "sampling_rate_hz": raw.info["sfreq"],
        "first_sample": raw.first_samp,
        "measurement_date": raw.info["meas_date"],
        "description": raw.info["description"],
        "custom_reference_applied": bool(raw.info["custom_ref_applied"]),
        "projectors": [{"description": p["desc"], "active": p["active"]} for p in raw.info["projs"]],
        "channels": [
            {"name": name, "type": kind,
             "mne_unit_code": int(ch["unit"]), "mne_unit_multiplier": int(ch["unit_mul"]),
             "data_unit": "V" if kind in {"eeg", "eog", "ecg", "emg"} else ("code" if kind == "stim" else None)}
            for name, kind, ch in zip(raw.ch_names, raw.get_channel_types(), raw.info["chs"])
        ],
    }
