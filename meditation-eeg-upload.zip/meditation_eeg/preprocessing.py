"""Conservative offline cleaning. Each recording has independent QC and ICA."""
import warnings

import mne
import numpy as np
import pandas as pd


def channel_quality(raw, config):
    picks = mne.pick_types(raw.info, eeg=True, exclude=[])
    rows = []
    for index, signal in zip(picks, raw.get_data(picks=picks), strict=True):
        if not np.isfinite(signal).all():
            raise ValueError(f"Nonfinite EEG samples in {raw.ch_names[index]}. Mark and repair the source recording.")
        uv = signal * 1e6
        spread = np.ptp(uv)
        robust_spread = np.diff(np.percentile(uv, [5, 95]))[0]
        rows.append({
            "channel": raw.ch_names[index], "peak_to_peak_uv": spread,
            "p95_minus_p05_uv": robust_spread, "std_uv": np.std(uv),
            "flat": spread < config["detect_flat_uv"],
            "potentially_noisy": robust_spread > config["flag_noisy_uv"],
        })
    return pd.DataFrame(rows)


def usable_eog(raw, index, flat_uv):
    samples = raw.get_data(picks=[index], reject_by_annotation="omit")
    return samples.size > 0 and np.isfinite(samples).all() and np.ptp(samples) * 1e6 > flat_uv


def inspect_ica(raw, picks, config):
    if not config["inspect_ica"]:
        return None, None, {"status": "skipped", "reason": "ICA inspection disabled", "removed": []}
    eog_picks = mne.pick_types(raw.info, eog=True, exclude="bads")
    eog = [index for index in eog_picks if usable_eog(raw, index, config["detect_flat_uv"])]
    if not eog:
        return None, None, {"status": "skipped", "reason": "No usable EOG channel. Review EEG and BAD intervals manually.", "removed": []}
    if len(picks) < 2 or raw.n_times / raw.info["sfreq"] < config["ica_min_seconds"]:
        return None, None, {"status": "skipped", "reason": "Insufficient channels or recording duration", "removed": []}
    fit = raw.copy().filter(1, None, picks=picks, skip_by_annotation=("edge", "bad"))
    eeg = fit.copy().pick(picks)
    rank = mne.compute_rank(eeg)["eeg"]
    if rank < 2 or eeg.get_data(reject_by_annotation="omit").shape[-1] < 20 * rank**2:
        return None, None, {"status": "skipped", "reason": "Insufficient rank or clean samples", "rank": rank, "removed": []}
    ica = mne.preprocessing.ICA(
        n_components=rank, method="fastica",
        random_state=42, max_iter=512,
    )
    ica.fit(fit, picks=picks, reject_by_annotation=True)
    if ica.n_iter_ >= 512:
        return None, None, {"status": "skipped", "reason": "ICA reached its iteration limit", "rank": rank, "removed": []}
    scores = []
    for index in eog:
        channel = raw.ch_names[index]
        candidates, values = ica.find_bads_eog(
            fit, ch_name=channel, measure="correlation", threshold=config["ica_eog_correlation"],
        )
        scores.append({
            "eog": channel, "candidate_components": [int(index) for index in candidates],
            "correlations": [float(value) if np.isfinite(value) else None for value in values],
        })
    return ica, ica.get_sources(fit), {"status": "inspection_only", "rank": rank, "removed": [], "eog_scores": scores}


def clean_raw(raw, config, interactive=False):
    cleaned = raw.copy()
    montage = config["montage"]
    if montage:
        # Only configure a named montage after verifying the physical layout.
        cleaned.set_montage(mne.channels.make_standard_montage(montage), on_missing="raise")
    quality = channel_quality(cleaned, config)
    manual = config["bad_channels"]
    if set(manual) - set(quality["channel"]):
        raise ValueError("Manual bad-channel list contains an absent or non-EEG channel.")
    cleaned.info["bads"] = sorted(set(cleaned.info["bads"]) | set(manual)
                                  | set(quality.loc[quality.flat, "channel"]))
    if interactive:
        cleaned.plot(block=True, scalings="auto")
        # A visually toggled flat trace still fails the configured detector.
        cleaned.info["bads"] = sorted(set(cleaned.info["bads"]) | set(quality.loc[quality.flat, "channel"]))
    original_bads = list(cleaned.info["bads"])
    quality["marked_bad"] = quality["channel"].isin(original_bads)
    picks = mne.pick_types(cleaned.info, eeg=True, exclude="bads")
    rate = cleaned.info["sfreq"]
    lo, hi = config["bandpass_hz"]
    if not 0 < lo < hi < rate / 2:
        raise ValueError(f"Bandpass {lo, hi} is incompatible with {rate:g} Hz acquisition.")
    if not (lo <= 4 and hi >= 30):
        raise ValueError("Bandpass should preserve the theta, alpha and beta bands.")
    cleaned.filter(lo, hi, picks=mne.pick_types(cleaned.info, eeg=True, exclude=[]),
                   skip_by_annotation=("edge", "bad"))
    ica, sources, artifact_report = inspect_ica(cleaned, picks, config)
    if config["inspect_ica"] and ica is None:
        warnings.warn(artifact_report["reason"], stacklevel=2)

    interpolated = []
    eeg_bads = quality.loc[quality.marked_bad, "channel"].tolist()
    if config["interpolate"] and eeg_bads:
        eeg = mne.pick_types(cleaned.info, eeg=True, exclude=[])
        positions = np.array([cleaned.info["chs"][index]["loc"][:3] for index in eeg])
        valid = (cleaned.get_montage() is not None and np.isfinite(positions).all()
                 and np.unique(positions, axis=0).shape[0] == len(positions)
                 and np.all(np.linalg.norm(positions, axis=1) > 0))
        if valid and picks.size >= max(4, len(eeg_bads) + 1):
            non_eeg_bads = sorted(set(original_bads) - set(eeg_bads))
            try:
                candidate = cleaned.copy().interpolate_bads(
                    reset_bads=True, exclude=non_eeg_bads, method={"eeg": "spline"},
                )
            except (RuntimeError, ValueError, np.linalg.LinAlgError) as error:
                warnings.warn(f"Interpolation skipped: {error}", stacklevel=2)
            else:
                cleaned = candidate
                interpolated = eeg_bads
        else:
            warnings.warn("Interpolation skipped because positions or good channels are insufficient.", stacklevel=2)
    reference = config["reference"]
    if reference == "average":
        if len(mne.pick_types(cleaned.info, eeg=True, exclude="bads")) < 2:
            warnings.warn("Average reference skipped: fewer than two included EEG channels.", stacklevel=2)
            # A requested reference must not silently change during feature extraction.
            cleaned.info["bads"] = sorted(set(cleaned.info["bads"]) | set(quality.channel))
        else:
            cleaned.set_eeg_reference("average", projection=False)
    elif reference != "preserve":
        raise ValueError("reference must be 'preserve' or 'average'.")
    quality["interpolated"] = quality["channel"].isin(interpolated)
    quality["excluded_from_epochs"] = quality["channel"].isin(cleaned.info["bads"])
    return cleaned, quality, ica, sources, artifact_report


def resample(raw, triggers, target_hz, lowpass):
    """Jointly map native events with MNE. Keep native clock when its origin would shift."""
    rate = raw.info["sfreq"]
    if target_hz is None or rate <= target_hz:
        return triggers, "native rate retained"
    if target_hz <= 2 * lowpass:
        raise ValueError("Target Nyquist must exceed the configured low-pass edge.")
    if not np.isclose(raw.first_time * target_hz, round(raw.first_time * target_hz), atol=1e-8, rtol=0):
        return triggers, "native rate retained to preserve fractional first-sample origin"
    groups = [(name, len(events)) for name, events in triggers.items()]
    if not sum(count for _, count in groups):
        raw.resample(target_hz)
        return triggers, "downsampled"
    combined = np.concatenate(list(triggers.values()))
    _, mapped = raw.resample(target_hz, events=combined)
    output = {}
    offset = 0
    for name, count in groups:
        output[name] = mapped[offset:offset + count]
        offset += count
    return output, "downsampled"
