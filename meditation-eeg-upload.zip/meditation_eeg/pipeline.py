"""Offline runner shared by the command line and notebook."""
import argparse
from collections import Counter
import json
from pathlib import Path
import re
import shutil
import tempfile
import tomllib

import mne
import numpy as np
import pandas as pd

from .features import extract_features, summarize
from .loading import discover, inventory, load_recording
from .preprocessing import clean_raw, resample
from .qc import plot_features, plot_ica, plot_signals
from .segmentation import annotations, create_epochs, find_triggers, resolve_stages


def read_config(path):
    path = Path(path).resolve()
    with path.open("rb") as handle:
        settings = tomllib.load(handle)
    for field in ("data_dir", "output_dir", "participants_csv"):
        settings["paths"][field] = path.parent / settings["paths"][field]
    if settings["stages"]["csv"]:
        settings["stages"]["csv"] = path.parent / settings["stages"]["csv"]
    return settings


def process(path, recording, settings, output, interactive=False):
    raw, source_info = load_recording(path, settings["channels"])
    duration = raw.n_times / raw.info["sfreq"]
    triggers = find_triggers(raw)
    mode = settings["mode"]
    if mode not in {"signal_only", "meditation"}:
        raise ValueError("mode must be 'signal_only' or 'meditation'.")
    stage_settings = settings["stages"]
    intervals = resolve_stages(raw, triggers, stage_settings, recording) if mode == "meditation" else None
    recording = {**recording, "stage_provenance": stage_settings["provenance"].strip() if intervals else ""}
    cleaned, quality, ica, sources, artifact_report = clean_raw(raw, settings["processing"], interactive)
    if ica is not None:
        ica.save(output / "inspection-ica.fif")
        plot_ica(sources, output)
    config = settings["processing"]
    mapped, resampling = resample(cleaned, triggers, config["target_hz"] or None, config["bandpass_hz"][1])
    epochs, candidates = create_epochs(cleaned, intervals, config, duration)
    interpolated = quality.loc[quality.interpolated, "channel"].tolist()
    features = extract_features(epochs, recording, interpolated)

    trigger_rows = []
    for channel, native_events in triggers.items():
        for native, current in zip(native_events, mapped[channel], strict=True):
            trigger_rows.append({
                "channel": channel, "native_sample": native[0], "previous_code": native[1],
                "code": native[2], "cleaned_sample": current[0],
                "onset_seconds": (native[0] - raw.first_samp) / raw.info["sfreq"],
                "cleaned_onset_seconds": (current[0] - cleaned.first_samp) / cleaned.info["sfreq"],
            })
    pd.DataFrame(trigger_rows, columns=["channel", "native_sample", "previous_code", "code", "cleaned_sample",
                                       "onset_seconds", "cleaned_onset_seconds"]).to_csv(output / "triggers.csv", index=False)
    pd.DataFrame(candidates, columns=["stage", "epoch_start_seconds", "sample", "reasons"]).to_csv(
        output / "epoch_qc.csv", index=False)
    features.to_csv(output / "features.csv", index=False)
    summarize(features).to_csv(output / "session_summary.csv", index=False)
    quality.to_csv(output / "channel_qc.csv", index=False)
    cleaned.save(output / "cleaned_raw.fif", fmt="double")
    retained = len(epochs) if epochs is not None else 0
    if retained:
        epochs.save(output / "cleaned-epo.fif", fmt="double")
    channels = [name for name in quality.channel if name not in cleaned.info["bads"]]
    plot_signals(raw, cleaned, channels or quality.channel.tolist(), output)
    plot_features(features, output)
    rejected = len(candidates) - retained
    report = {
        **recording, "mode": mode, "source": source_info, "cleaned": inventory(cleaned),
        "acquisition_reference_reported": settings["channels"]["acquisition_reference"],
        "run_settings": {name: settings[name] for name in ("channels", "processing", "stages")},
        "mne_version": mne.__version__, "resampling": resampling, "annotation_time_origin": raw.annotations.orig_time,
        "original_annotations": annotations(raw), "cleaned_annotations": annotations(cleaned),
        "stage_intervals": intervals, "ica": artifact_report, "interpolated": interpolated,
        "trigger_codes": {name: np.unique(events[:, 2]).tolist() for name, events in triggers.items()},
        "candidate_epochs": len(candidates), "retained_epochs": retained, "rejected_epochs": rejected,
        "retained_proportion": retained / len(candidates) if candidates else None,
        "rejected_proportion": rejected / len(candidates) if candidates else None,
        "rejection_reasons": Counter(reason for row in candidates for reason in row["reasons"]),
    }
    (output / "qc.json").write_text(json.dumps(report, indent=2, default=str))
    return report


def run(settings, filename=None, interactive=False):
    paths = settings["paths"]
    files = discover(paths["data_dir"], settings["channels"]["legacy_mat_enabled"])
    if filename is not None:
        files = [path for path in files if path.name == filename]
    if not files:
        raise FileNotFoundError(f"No matching recordings in {paths['data_dir']}")
    participants = pd.read_csv(paths["participants_csv"], dtype=str, keep_default_na=False)
    if participants.file.duplicated().any():
        raise ValueError("Participant metadata must contain one row per input filename.")
    participants = participants.set_index("file")
    output = Path(paths["output_dir"])
    output.mkdir(parents=True, exist_ok=True)
    jobs, destinations = [], set()
    for path in files:
        if path.name not in participants.index:
            raise ValueError(f"Add anonymized participant/session IDs for {path.name} in the metadata CSV.")
        identity = participants.loc[path.name, ["participant_id", "session_id"]].to_dict()
        if any(not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]*", value) for value in identity.values()):
            raise ValueError("Use short pseudonymous IDs with only letters, digits, hyphens and underscores.")
        destination = output / identity["participant_id"] / identity["session_id"]
        if destination.exists() or destination in destinations:
            raise FileExistsError(f"Use a fresh output directory and unique participant/session pairs: {destination}")
        destinations.add(destination)
        jobs.append((path, {"file": path.name, **identity}, destination))
    reports = []
    for path, identity, destination in jobs:
        temporary = Path(tempfile.mkdtemp(prefix=".processing-", dir=output))
        try:
            report = process(path, identity, settings, temporary, interactive)
            destination.parent.mkdir(parents=True, exist_ok=True)
            temporary.rename(destination)
        finally:
            if temporary.exists():
                shutil.rmtree(temporary)
        reports.append(report)
    return reports


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="config.toml")
    parser.add_argument("--file", help="Process a single input filename.")
    parser.add_argument("--interactive", action="store_true", help="Open MNE's bad-channel and annotation browser.")
    args = parser.parse_args()
    for report in run(read_config(args.config), args.file, args.interactive):
        print(f"{report['participant_id']}/{report['session_id']}  "
              f"{report['retained_epochs']}/{report['candidate_epochs']} epochs retained")


if __name__ == "__main__":
    main()
